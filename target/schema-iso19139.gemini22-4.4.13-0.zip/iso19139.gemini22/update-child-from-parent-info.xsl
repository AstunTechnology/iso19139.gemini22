<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:import href="../iso19139/update-child-from-parent-info.xsl"/>
</xsl:stylesheet>

<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns    ="http://www.isotc211.org/2005/gmd"
										xmlns:gco="http://www.isotc211.org/2005/gco"
										xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
										xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
										>

	<!-- ============================================================================= -->

	<xsl:template name="RefSystemTypes">
		<xsl:param name="srs">27700</xsl:param>
		<referenceSystemIdentifier>
			<RS_Identifier>
				<code>
                    <!-- Add WGS84 if exist else add only the first one to avoid to have the full list of CRS supported.
                        OGC Clients should use the GetCapabilities to get this information  -->
					<xsl:choose>
						<xsl:when test="count(//SRS='EPSG:27700')!=0">
           					<gco:CharacterString>27700</gco:CharacterString>
           				</xsl:when>
           				<xsl:otherwise>
           					<gco:CharacterString><xsl:value-of select="//SRS[0]/."/></gco:CharacterString>
           				</xsl:otherwise>
         			</xsl:choose>
           		</code>
			</RS_Identifier>
		</referenceSystemIdentifier>
	</xsl:template>



	<!-- ============================================================================= -->

</xsl:stylesheet>
